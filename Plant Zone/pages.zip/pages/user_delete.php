
    <!-- dynamic content will be here -->
<?php
include '../config/dbconn.php';
$id = $_GET['user_id'];
$result = mysqli_query($dbconn, "DELETE FROM users WHERE user_id=$id");
header("Location:admin_panel.php");
?>
    